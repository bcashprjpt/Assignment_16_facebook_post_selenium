from selenium import webdriver
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

driver = webdriver.Chrome()
driver.get('https://www.facebook.com/')

time.sleep(2)
email_element = driver.find_element(By.XPATH,'.//*[@id="email"]')
email_element.send_keys('6371016609')

time.sleep(2)
password_element = driver.find_element(By.XPATH,'.//*[@id="pass"]')
password_element.send_keys('Testkumar@123')

time.sleep(2)
button_element = driver.find_element(By.NAME,'login')
button_element.click()

time.sleep(5)
try:
    time.sleep(10)
   # driver.find_element(By.XPATH,'//*[@class = "x6s0dn4 x9f619 x78zum5 x1iyjqo2 x1s65kcs x17qophe x1d52u69 xixxii4 x13vifvy xzkaem6"]').click()

    status_element = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.XPATH,'//*[@class="x1i10hfl x1ejq31n xd10rxx x1sy0etr x17r0tee x972fbf xcfux6l x1qhh985 xm0m39n x9f619 x1ypdohk xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r x16tdsg8 x1hl2dhg xggy1nq x87ps6o x1lku1pv x1a2a7pz x6s0dn4 xmjcpbm x107yiy2 xv8uw2v x1tfwpuw x2g32xy x78zum5 x1q0g3np x1iyjqo2 x1nhvcw1 x1n2onr6 xt7dq6l x1ba4aug x1y1aw1k xn6708d xwib8y2 x1ye3gou"]')))
    status_element.click()

    post_element = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.XPATH,'//*[@class="xdj266r x11i5rnm xat24cr x1mh8g0r x16tdsg8"]' )) )
    post_element.send_keys("HELLO TUTEDUDE")

    time.sleep(5)
    button = driver.find_element(By.XPATH,'//*[@class = "x1ja2u2z x78zum5 x2lah0s x1n2onr6 xl56j7k x6s0dn4 xozqiw3 x1q0g3np xi112ho x17zwfj4 x585lrc x1403ito x972fbf xcfux6l x1qhh985 xm0m39n x9f619 xn6708d x1ye3gou xtvsq51 x1r1pt67"]')
    button.click()
except Exception as e:
    print(e)
time.sleep(10)






'''status_element.send_keys("Hello facebook")
time.sleep(5)

buttons =  driver.find_element(By.TAG_NAME,'button')
time.sleep(5)

for button in buttons:
    if button.text == 'Post':
        button.click()'''


'''# Wait and click the "What's on your mind?" post button
try:
    post_button = WebDriverWait(driver, 20).until(
        EC.element_to_be_clickable((By.XPATH, "//span[contains(text(),\"What's on your mind, Test?\")]/div[@role='button']"))
    )
    post_button.click()
    print("Clicked on 'What's on your mind?' successfully.")
except Exception as e:
    print("Failed to click on 'What's on your mind?':", e)

time.sleep(30)
driver.quit()'''


